export const environment = {
  production: true,
  firebaseconfig:{
    apiKey: "AIzaSyCiOqDZv9p51SpgypVDr-QK5FbHjM5GVE4",
    authDomain: "torneo-9b3bb.firebaseapp.com",
    projectId: "torneo-9b3bb",
    storageBucket: "torneo-9b3bb.appspot.com",
    messagingSenderId: "96012678643",
    appId: "1:96012678643:web:0e5de24cd74e5f4b4d8e86",
    measurementId: "G-NW5YBKFPZL"
  }
};
