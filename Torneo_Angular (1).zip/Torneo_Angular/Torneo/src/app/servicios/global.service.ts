export var GLOBAL = {
 /* url: 'https://grupo3torneo.herokuapp.com/'*/
 url:'http://localhost:3000/api/'
}
