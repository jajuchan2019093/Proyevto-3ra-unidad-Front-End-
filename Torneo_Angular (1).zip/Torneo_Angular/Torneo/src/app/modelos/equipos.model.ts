export class Equipos{
    constructor(
      public _id: String,
      public nombre: String,
    ){}
  }
