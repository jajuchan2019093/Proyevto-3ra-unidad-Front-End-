export class Ligas{
  constructor(
    public _id: String,
    public nombre: String,
    public autor: String,
  ){}
}
